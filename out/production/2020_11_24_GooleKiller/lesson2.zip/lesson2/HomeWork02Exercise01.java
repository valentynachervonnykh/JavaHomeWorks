package lesson2;

public class HomeWork02Exercise01 {
    public static void main(String[] args) {
        findPerimeter();
        findSquare();
    }

    public static void findPerimeter() {
        int a = 10;
        int perimeter = 4 * a;
        System.out.println("периметр квадрата  равен: " + perimeter);
    }

    public static void findSquare() {
        int a = 10;
        int quadrantSquare = a * a;
        int Square = 16 * quadrantSquare;
        System.out.println("площадь квадрата равен: " + quadrantSquare);
    }
}


