package lesson2;

public class HomeWork2Exercise03 {


    public static void main(String[] args) {
        findPerimeter();
        findSquare();
    }

    public static void findPerimeter() {
        int a = 10;
        int perimeter = (a + a);
        System.out.println("периметр прямоугольника  равен: " + perimeter);
    }

    public static void findSquare() {
        int a = 10;
        int rectangleSquare = a * a;
        int Square = 16 * rectangleSquare;
        System.out.println("площадь прямоугольника равен: " + rectangleSquare);
    }
    }
